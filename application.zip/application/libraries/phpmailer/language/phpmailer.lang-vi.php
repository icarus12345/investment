<?php

/**
 * Vietnamese Version
 */
$PHPMAILER_LANG['provide_address'] = 'Bạn chưa nhập địa chỉ email người nhận!';
$PHPMAILER_LANG['mailer_not_supported'] = ' mailer không được hỗ trợ.';
$PHPMAILER_LANG['execute'] = 'Không thể thực hiện: ';
$PHPMAILER_LANG['instantiate'] = 'Không thể thực hiện hàm mail.';
$PHPMAILER_LANG['authenticate'] = 'Lỗi SMTP: Không thể chứng thực.';
$PHPMAILER_LANG['from_failed'] = 'Địa chỉ người gởi sai: ';
$PHPMAILER_LANG['recipients_failed'] = 'Lỗi SMTP: Địa chỉ người nhận sai: ';
$PHPMAILER_LANG['data_not_accepted'] = 'Lỗi SMTP: Dữ liệu không hợp lệ.';
$PHPMAILER_LANG['connect_host'] = 'Lỗi SMTP: Không kết nối được với SMTP host.';
$PHPMAILER_LANG['file_access'] = 'Không thể truy xuất file: ';
$PHPMAILER_LANG['file_open'] = 'Lỗi File: Không thể mở file: ';
$PHPMAILER_LANG['encoding'] = 'Lỗi encoding: ';
$PHPMAILER_LANG['signing'] = 'Lỗi Signing: ';
$PHPMAILER_LANG['smtp_error'] = 'Lỗi SMTP server: ';
$PHPMAILER_LANG['empty_message'] = 'Nội dung rỗng';
$PHPMAILER_LANG['invalid_address'] = 'Địa chỉ không hợp lệ';
$PHPMAILER_LANG['variable_set'] = 'Không thể khởi tạo biến: '
?>