<?php /* Smarty version Smarty-3.1.21-dev, created on 2017-02-03 09:28:24
         compiled from "application\templates\funny\sidebar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:295255855553fd1c952-31583304%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f261eeb1081a7b545d3969bbb3e2a82385f3de8f' => 
    array (
      0 => 'application\\templates\\funny\\sidebar.tpl',
      1 => 1486088876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '295255855553fd1c952-31583304',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5855553fd59b78_14063646',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5855553fd59b78_14063646')) {function content_5855553fd59b78_14063646($_smarty_tpl) {?><div class="scrollable">
  <h3 class="scrollable-header app-name">MENU <small>.</small></h3>  
  <div class="scrollable-content">
    <div class="list-group" ui-turn-off='uiSidebarLeft'>
      <a class="list-group-item" href="#/">Cười</i></a>
      <a class="list-group-item" href="#/image">Hình Ảnh </i></a>
      <a class="list-group-item" href="#/video">Video </i></a>
      <a class="list-group-item" href="#/tabs">Girl </i></a>
      <a class="list-group-item" href="#/accordion">Gif </i></a>
      <a class="list-group-item" href="#/overlay">Overlay </i></a>
      <a class="list-group-item" href="#/forms">Forms </i></a>
      <a class="list-group-item" href="#/dropdown">Dropdown </i></a>
      <a class="list-group-item" href="#/touch">Touch</i></a>
      <a class="list-group-item" href="#/swipe">Swipe</i></a>
      <a class="list-group-item" href="#/drag">Drag 1</i></a>
      <a class="list-group-item" href="#/image/detail/21">Detail</i></a>
      <a class="list-group-item" href="#/image/add" >Add Image</i></a>
    </div>
  </div>
</div>
<?php }} ?>
