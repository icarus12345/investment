<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-12-10 15:03:57
         compiled from "application\templates\dashboard\so\setting\pageheader.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2416584bb6ed4b9a00-11353518%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '91aa87efb115012fbd3deaa8cd2d2cf5a425d316' => 
    array (
      0 => 'application\\templates\\dashboard\\so\\setting\\pageheader.tpl',
      1 => 1436337420,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2416584bb6ed4b9a00-11353518',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_584bb6ed4bd3f7_32717609',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584bb6ed4bd3f7_32717609')) {function content_584bb6ed4bd3f7_32717609($_smarty_tpl) {?><!-- BEGIN PAGE HEADER-->

<h3 class="page-title">
	Dashboard <small>Setting</small>
</h3>

<div class="page-bar">
	<ul class="page-breadcrumb">
		<li>
			<i class="fa fa-home"></i>
			<a href="/dashboard">Dashboard</a>
			<i class="fa fa-angle-right"></i>
		</li>
		<li>
			<a href="/dashboard/so">Service Operator</a>
			<i class="fa fa-angle-right"></i>
		</li>
		<li>
			<a href="#">Setting</a>
		</li>
	</ul>
	<!-- <div class="page-toolbar">
		<div id="dashboard-report-range" class="pull-right tooltips btn btn-fit-height grey-salt" data-placement="top" data-original-title="Change dashboard date range">
			<i class="icon-calendar"></i>&nbsp; <span class="thin uppercase visible-lg-inline-block"></span>&nbsp; <i class="fa fa-angle-down"></i>
		</div>
	</div> -->
</div>
<!-- END PAGE HEADER--><?php }} ?>
