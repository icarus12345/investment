<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-12-11 20:17:08
         compiled from "application\templates\dashboard\so\account\pageheader.tpl" */ ?>
<?php /*%%SmartyHeaderCode:30222584d51d412c377-19874226%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3e1b372260d402d5b0261717ba1677a0327f7847' => 
    array (
      0 => 'application\\templates\\dashboard\\so\\account\\pageheader.tpl',
      1 => 1436323800,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '30222584d51d412c377-19874226',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_584d51d41eaa49_80810194',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584d51d41eaa49_80810194')) {function content_584d51d41eaa49_80810194($_smarty_tpl) {?><!-- BEGIN PAGE HEADER-->

<h3 class="page-title">
	Dashboard <small>Account</small>
</h3>

<div class="page-bar">
	<ul class="page-breadcrumb">
		<li>
			<i class="fa fa-home"></i>
			<a href="/dashboard">Dashboard</a>
			<i class="fa fa-angle-right"></i>
		</li>
		<li>
			<a href="/dashboard/so">Service Operator</a>
			<i class="fa fa-angle-right"></i>
		</li>
		<li>
			<a href="#">Account</a>
		</li>
	</ul>
	<!-- <div class="page-toolbar">
		<div id="dashboard-report-range" class="pull-right tooltips btn btn-fit-height grey-salt" data-placement="top" data-original-title="Change dashboard date range">
			<i class="icon-calendar"></i>&nbsp; <span class="thin uppercase visible-lg-inline-block"></span>&nbsp; <i class="fa fa-angle-down"></i>
		</div>
	</div> -->
</div>
<!-- END PAGE HEADER--><?php }} ?>
