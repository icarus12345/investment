<?php /* Smarty version Smarty-3.1.21-dev, created on 2017-02-03 09:28:24
         compiled from "application\templates\funny\modal.tpl" */ ?>
<?php /*%%SmartyHeaderCode:341058569db432d687-57735891%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f0ad72de91637cc8e2cac3a42c1d41709f1be502' => 
    array (
      0 => 'application\\templates\\funny\\modal.tpl',
      1 => 1486088876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '341058569db432d687-57735891',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_58569db438e6f6_03327174',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58569db438e6f6_03327174')) {function content_58569db438e6f6_03327174($_smarty_tpl) {?><div class="modal modal-overlay" ui-if='modal2' ui-state='modal2'>
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button class="close"
                ui-turn-off="modal2">&times;</button>
        <h4 class="modal-title">Modal title</h4>
      </div>
      <!-- <div class="modal-footer">
        <button ui-turn-off="modal2" class="btn btn-default">Close</button>
        <button ui-turn-off="modal2" class="btn btn-primary">Save changes</button>
      </div> -->
      <div class="modal-body">
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
        <p>lorem</p>
      </div>
      
    </div>
  </div>
</div><?php }} ?>
