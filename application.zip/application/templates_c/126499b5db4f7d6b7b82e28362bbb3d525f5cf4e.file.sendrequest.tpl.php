<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-12-11 20:55:51
         compiled from "application\templates\investment\widget\sendrequest.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20161584d5a9ab93819-70281845%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '126499b5db4f7d6b7b82e28362bbb3d525f5cf4e' => 
    array (
      0 => 'application\\templates\\investment\\widget\\sendrequest.tpl',
      1 => 1481464523,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20161584d5a9ab93819-70281845',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_584d5a9ab974a1_88654605',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584d5a9ab974a1_88654605')) {function content_584d5a9ab974a1_88654605($_smarty_tpl) {?>
        <form id="subcribeFrm" name="subcribeFrm" class="validationFrm">
            <div class="pull-top pull-bottom">
                <div class=" control-group ">
                    <input type="text" class="form-control validate[required,maxSize[50]]" placeholder="Name">
                </div>
            </div>
            <div class="pull-bottom pull-top">
                <div class="control-group">
                    <input type="text" class="form-control validate[required,custom[email]]" placeholder="Email" >
                </div>
            </div>

            <div class="pull-bottom pull-top">
                <div class="control-group">
                    <input type="text" class="form-control validate[required,maxSize[250]]" placeholder="Subject" >
                </div>
            </div>

            <div class="pull-bottom pull-top">
                <div class="control-group">
                    <textarea rows="10" class="form-control validate[required]" placeholder="Your message..." ></textarea>
                </div>
            </div>
            <div class=" pull-top">
            <button type="submit" class="btn btn-orange pull-right" style="padding: 8px 40px"><span>SEND</span></button>
            </div>
        </form><?php }} ?>
