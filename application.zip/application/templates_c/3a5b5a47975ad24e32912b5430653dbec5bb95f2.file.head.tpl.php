<?php /* Smarty version Smarty-3.1.21-dev, created on 2017-02-05 15:06:36
         compiled from "application\templates\eye\inc\head.tpl" */ ?>
<?php /*%%SmartyHeaderCode:79275896dc1bf1c314-71571731%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a5b5a47975ad24e32912b5430653dbec5bb95f2' => 
    array (
      0 => 'application\\templates\\eye\\inc\\head.tpl',
      1 => 1486281994,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '79275896dc1bf1c314-71571731',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5896dc1bf20f99_48626566',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5896dc1bf20f99_48626566')) {function content_5896dc1bf20f99_48626566($_smarty_tpl) {?>        <header id="navbar" class="navbar navbar-fixed-top" role="banner">
            <!-- Menu [ -->
            <div class="">

                    <div class="navbar-header">
                        <a href="/" class="navbar-brand"></a>
                        <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#navigation">
                            <span>
                                <span class="icon-bar line-1"></span>
                                <span class="icon-bar line-2"></span>
                                <span class="icon-bar line-3"></span>
                            </span>
                        </button>
                    </div>
                    <nav id="navigation" class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
                        <ul class="nav navbar-nav">
                            <li data-menu="home"><a href='/'>HOME</a></li>
                            <li data-menu="patients"><a href='/patients'>PATIENTS</a></li>
                            <li data-menu="about"><a href='/about'>ABOUT AE&LC</a></li>
                            <li data-menu="referrals"><a href='/referrals'>REFERRALS</a></li>
                            <li data-menu="services"><a href='/services'>SERVICES</a></li>
                            <li data-menu="news"><a href='/news'>LAST NEWS</a></li>
                            <li data-menu="contact"><a href='/contact'>CONTACT US</a></li>
                        </ul>
                    </nav>
                    <div class="search-box">
                        <a href="#" class="btn btn-info">VIRTUAL TOUR</a>
                        <a href="#" class="fb"></a>
                        <a href="#" class="search"></a>
                    </div>
            </div>
            <!-- Menu ] -->
        </header><?php }} ?>
