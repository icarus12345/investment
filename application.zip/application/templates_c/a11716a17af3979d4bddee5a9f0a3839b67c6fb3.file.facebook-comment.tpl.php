<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-12-10 16:16:11
         compiled from "application\templates\investment\widget\facebook-comment.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2813584bc76763fa23-51132601%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a11716a17af3979d4bddee5a9f0a3839b67c6fb3' => 
    array (
      0 => 'application\\templates\\investment\\widget\\facebook-comment.tpl',
      1 => 1481361288,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2813584bc76763fa23-51132601',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_584bc767645b53_35962573',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584bc767645b53_35962573')) {function content_584bc767645b53_35962573($_smarty_tpl) {?><div class="fb-comments" data-width="100%" data-href="<?php echo current_url();?>
" data-numposts="5"></div><?php }} ?>
