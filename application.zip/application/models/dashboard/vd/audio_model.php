<?php

class audio_model extends Core_Model {

    function __construct(){
        parent::__construct('_audio','audio_','id');
    }
    
}
?>