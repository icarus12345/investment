<?php

class video_model extends Core_Model {

    function __construct(){
        parent::__construct('_video','video_','id');
    }
    
}
?>