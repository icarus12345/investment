<?php

class contact_model extends Core_Model {

    function __construct(){
        parent::__construct('contactus','contact_','id');
    }
    
}
?>
