<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of webpage_model
 *
 * @author Admin
 */
class webpage_model {
    //put your code here
}

?>
