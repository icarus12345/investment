<?php

class album_model extends Core_Model {

    function __construct(){
        parent::__construct('album','album_','id');
    }
    
}
?>
